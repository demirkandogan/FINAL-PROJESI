﻿using System;
using System.Collections.Generic;

namespace YeniDB.data
{
    public partial class OkulYonetim
    {
        public OkulYonetim()
        {
            DersTs = new HashSet<DersT>();
        }

        public int Id { get; set; }
        public string? AdSoyad { get; set; }
        public string? Gorevi { get; set; }
        public int? YonetimTip { get; set; }

        public virtual ICollection<DersT> DersTs { get; set; }
    }
}
