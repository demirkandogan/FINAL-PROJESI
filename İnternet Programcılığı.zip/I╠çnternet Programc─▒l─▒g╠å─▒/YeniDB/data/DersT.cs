﻿using System;
using System.Collections.Generic;

namespace YeniDB.data
{
    public partial class DersT
    {
        public DersT()
        {
            OgrenciDersTs = new HashSet<OgrenciDersT>();
        }

        public int Id { get; set; }
        public string? Ad { get; set; }
        public double? Kredisi { get; set; }
        public int? OkulYonetimId { get; set; }

        public virtual OkulYonetim? OkulYonetim { get; set; }
        public virtual ICollection<OgrenciDersT> OgrenciDersTs { get; set; }
    }
}
