﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace OkulDB.data
{
    public partial class YeniContext : DbContext
    {
        public YeniContext()
        {
        }

        public YeniContext(DbContextOptions<YeniContext> options)
            : base(options)
        {
        }

        public virtual DbSet<DersT> DersTs { get; set; } = null!;
        public virtual DbSet<Ogrenci> Ogrencis { get; set; } = null!;
        public virtual DbSet<OgrenciDersT> OgrenciDersTs { get; set; } = null!;
        public virtual DbSet<OkulYonetim> OkulYonetims { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=.\\SQLEXPRESS;Database=Yeni;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DersT>(entity =>
            {
                entity.ToTable("DersT");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Ad).HasMaxLength(50);

                entity.Property(e => e.OkulYonetimId).HasColumnName("OkulYonetimID");

                entity.HasOne(d => d.OkulYonetim)
                    .WithMany(p => p.DersTs)
                    .HasForeignKey(d => d.OkulYonetimId)
                    .HasConstraintName("FK_DersT_OkulYonetim");
            });

            modelBuilder.Entity<Ogrenci>(entity =>
            {
                entity.ToTable("Ogrenci");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.AdSoyad).HasMaxLength(50);

                entity.Property(e => e.Bolum).HasMaxLength(50);

                entity.Property(e => e.Dtarih)
                    .HasColumnType("date")
                    .HasColumnName("DTarih");

                entity.Property(e => e.KayitTarih).HasColumnType("date");
            });

            modelBuilder.Entity<OgrenciDersT>(entity =>
            {
                entity.ToTable("OgrenciDersT");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.DersId).HasColumnName("DersID");

                entity.Property(e => e.OgrenciId).HasColumnName("OgrenciID");

                entity.HasOne(d => d.Ders)
                    .WithMany(p => p.OgrenciDersTs)
                    .HasForeignKey(d => d.DersId)
                    .HasConstraintName("FK_OgrenciDersT_DersT");

                entity.HasOne(d => d.Ogrenci)
                    .WithMany(p => p.OgrenciDersTs)
                    .HasForeignKey(d => d.OgrenciId)
                    .HasConstraintName("FK_OgrenciDersT_Ogrenci");
            });

            modelBuilder.Entity<OkulYonetim>(entity =>
            {
                entity.ToTable("OkulYonetim");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.AdSoyad).HasMaxLength(50);

                entity.Property(e => e.Gorevi).HasMaxLength(50);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
