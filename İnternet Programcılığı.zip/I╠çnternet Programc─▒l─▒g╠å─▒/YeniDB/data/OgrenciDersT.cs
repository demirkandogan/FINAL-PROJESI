﻿using System;
using System.Collections.Generic;

namespace YeniDB.data
{
    public partial class OgrenciDersT
    {
        public int Id { get; set; }
        public int? DersId { get; set; }
        public int? OgrenciId { get; set; }

        public virtual DersT? Ders { get; set; }
        public virtual Ogrenci? Ogrenci { get; set; }
    }
}
