﻿using Microsoft.AspNetCore.Mvc;

namespace YeniDB.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
