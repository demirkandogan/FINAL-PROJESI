﻿using Microsoft.AspNetCore.Mvc;
using YeniDB.data;
using YeniDB.Models;
using System.Diagnostics;

namespace YeniDB.Controllers
{
    public class OgrenciDersController : Controller
    {
        private readonly ILogger<OgrenciDersController> _logger;
        private YeniContext _yeniContext;

        public OgrenciDersController(ILogger<OgrenciDersController> logger, YeniContext yeniContext)
        {
            _logger = logger;
            _yeniContext = yeniContext;
        }

        public IActionResult Index()
        {
            OgrenciDersModel ogrenciDersModel = new OgrenciDersModel();
            ogrenciDersModel.OgrenciDersList = new List<OgrenciDers>();
            var data = _yeniContext.OgrenciDersTabs.ToList();
            foreach (var item in data)
            {
                ogrenciDersModel.OgrenciDersList.Add(new OgrenciDers
                {
                    ID = item.Id,
                    DersId = item.Id,
                    OgrenciId = item.Id

                });
            }

            return View(ogrenciDersModel);
        }

        [HttpGet]
        public IActionResult Kaydet()
        {
            OgrenciDers ogrenciDers = new OgrenciDers();
            return View(ogrenciDers);
        }
        [HttpPost]
        public IActionResult Kaydet(OgrenciDers ogrenciDers)
        {
            try
            {
                var ogrenciDersveri = new OgrenciDersT()
                {
                    ID = ogrenciDers.ID,
                    DersID = ogrenciDers.DersID,
                    OgrenciID = ogrenciDers.ID
                };
                _yeniContext.OgrenciDersTabs.Add(ogrenciDersveri);
                _yeniContext.SaveChanges();
                TempData["SaveStatus"] = 1;
            }
            catch (Exception ex)
            {
                TempData["SaveStatus"] = 0;
            }
            return RedirectToAction("Index", "OgrenciDers");
        }
        [HttpGet]
        public IActionResult Guncelle(int Id = 0)
        {
            OgrenciDersT ogrenciDers = new OgrenciDersT();
            var data = _yeniContext.OgrenciDersTs.Where(m => m.Id == Id).FirstOrDefault();
            if (data != null)
            {
                ogrenciDers.Id = data.Id;
                ogrenciDers.DersId = data.Id;
                ogrenciDers.OgrenciId = data.Id;
            }
            return View(ogrenciDers);
        }
        [HttpPost]
        public IActionResult Guncelle(OgrenciDersT ogrenciDers)
        {
            try
            {
                var data = _yeniContext.OgrenciDersTabs.Where(m => m.Id == ogrenciDers.Id).FirstOrDefault();
                data.DersId = ogrenciDers.DersId;
                data.OgrenciId = ogrenciDers.Id;
                _yeniContext.SaveChanges();
                TempData["UpdateStatus"] = 1;
            }
            catch
            {
                TempData["UpdateStatus"] = 0;
            }
            return RedirectToAction("Index", "OgrenciDersT");
        }
        [HttpGet]
        public IActionResult Sil(int Id = 0)
        {
            try
            {
                var data = _yeniContext.OgrenciDersTabs.Where(m => m.Id == Id).FirstOrDefault();
                if (data != null)
                {
                    _yeniContext.OgrenciDersTs.Remove(data);
                    _yeniContext.SaveChanges();
                }
                TempData["DeleteStatus"] = 1;

            }
            catch
            {
                TempData["DeleteStatus"] = 0;
            }
            return RedirectToAction("Index", "OgrenciDers");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}